﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public static class CommonConstant
    {
        public static string USER_SESSION = "USER_SESSION";
    }
}
